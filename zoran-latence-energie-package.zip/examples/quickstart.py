from zlatence.core import ZoranLatenceEnergie

zle = ZoranLatenceEnergie()
print(zle.mesurer_latence(lambda: sum(range(1000))))
print(zle.log_energie(12.5))
print(zle.get_logs())
