import time

class ZoranLatenceEnergie:
    def __init__(self):
        self.logs = []
    def mesurer_latence(self, func, *args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()
        latence = (end - start) * 1e6  # µs
        self.logs.append(('latence', latence))
        return latence, result
    def log_energie(self, joules):
        self.logs.append(('energie', joules))
        return "Energie loggée"
    def get_logs(self):
        return self.logs
