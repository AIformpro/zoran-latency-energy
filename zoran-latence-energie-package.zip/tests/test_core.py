from zlatence.core import ZoranLatenceEnergie

def test_mesurer_latence():
    zle = ZoranLatenceEnergie()
    latence, _ = zle.mesurer_latence(lambda: sum(range(10)))
    assert latence > 0
